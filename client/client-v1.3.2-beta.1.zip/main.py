from client import is_pressed, turn_right, turn_left, forward, turn_towards, get_position, interact, attack, equip, unequip, set_skin, get_map, stop_actions, connect_to, get_inventory

connect_to(("127.0.0.1", 5001))

set_skin('a')

while True:
    if is_pressed('w'):
        forward()
    elif is_pressed('d'):
        turn_right()
    elif is_pressed('a'):
        turn_left()
    elif is_pressed('e'):
        interact('open')
    elif is_pressed(' '):
        attack()
    elif is_pressed('q'):
        interact('put', '')
    elif is_pressed('z'):
        print(interact('show'))
    elif is_pressed('x'):
        interact('take', '')
    elif is_pressed('c'):
        interact('put', '')
    elif is_pressed('r'):
        interact('craft', '')
    elif is_pressed('f'):
        equip('', '')
    elif is_pressed('g'):
        unequip('')
    elif is_pressed('m'):
        print(get_map())
    elif is_pressed('s'):
        stop_actions()
